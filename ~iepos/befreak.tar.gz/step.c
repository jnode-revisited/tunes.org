#include <stdio.h>
#include <stdlib.h>
#include "bfi.h"

void step(int n){
  int c,i;
  unsigned x,y;
  static char stringmode=0;

  i=n;
  do{
    c = code.text[code.ipy*code.lenx+code.ipx];
    if(stringmode){
      if(c=='"') stringmode=0;
      else if(code.invert){
	if(DLEN==0 || DATA(1)!=c) goto error;
	DLEN--;
      }else{
	DPUSH(c);
      }
    }else switch(c){
    case '"':
      stringmode=1;
      break;
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
      if(DLEN==0) goto error;
      if(code.invert){
	x=c-'0';
	y=10;
	for(;;){
	  MOVE(code,ip);
	  c = code.text[code.ipy*code.lenx+code.ipx];
	  if(c<'0' || c>'9') break;
	  x+=(c-'0')*y;
	  y*=10;
	}
      }else{
	x=c-'0';
	for(;;){
	  MOVE(code,ip);
	  c = code.text[code.ipy*code.lenx+code.ipx];
	  if(c<'0' || c>'9') break;
	  x=x*10+c-'0';
	}
      }
      DATA(1) ^= x;
      continue;
    case '>':
      switch(code.ipdir){
      case NORTH: 
	RPUSH(code.invert^1); 
	code.ipdir=EAST;
	break;
      case SOUTH: 
	RPUSH(code.invert); 
	code.ipdir=EAST;
	break;
      case WEST: 
	if(RLEN==0) goto error;
	if(RET(1)==code.invert) code.ipdir=SOUTH;
	else if(RET(1) == !code.invert) code.ipdir=NORTH;
	else goto error;
	RLEN--;
	break;
      case EAST: 
	if(RLEN==0) goto error;
	if(RET(1)==0) RET(1)=1;
	else if(RET(1)==1) RET(1)=0;
	else goto error;
	code.ipdir ^= 1;
	code.invert ^= 1;
	break;
      }
      break;
    case '<':
      switch(code.ipdir){
      case NORTH: 
	RPUSH(code.invert); 
	code.ipdir=WEST;
	break;
      case SOUTH: 
	RPUSH(code.invert^1); 
	code.ipdir=WEST;
	break;
      case EAST: 
	if(RLEN==0) goto error;
	if(RET(1)==code.invert) code.ipdir=NORTH;
	else if(RET(1) == !code.invert) code.ipdir=SOUTH;
	else goto error;
	RLEN--;
	break;
      case WEST: 
	if(RLEN==0) goto error;
	if(RET(1)==0) RET(1)=1;
	else if(RET(1)==1) RET(1)=0;
	else goto error;
	code.ipdir ^= 1;
	code.invert ^= 1;
	break;
      }
      break;
    case 'v':
      switch(code.ipdir){
      case EAST: 
	RPUSH(code.invert^1); 
	code.ipdir=SOUTH;
	break;
      case WEST: 
	RPUSH(code.invert); 
	code.ipdir=SOUTH;
	break;
      case NORTH: 
	if(RLEN==0) goto error;
	if(RET(1)==code.invert) code.ipdir=WEST;
	else if(RET(1) == !code.invert) code.ipdir=EAST;
	else goto error;
	RLEN--;
	break;
      case SOUTH: 
	if(RLEN==0) goto error;
	if(RET(1)==0) RET(1)=1;
	else if(RET(1)==1) RET(1)=0;
	else goto error;
	code.ipdir ^= 1;
	code.invert ^= 1;
	break;
      }
      break;
    case '^':
      switch(code.ipdir){
      case WEST: 
	RPUSH(code.invert^1); 
	code.ipdir=NORTH;
	break;
      case EAST: 
	RPUSH(code.invert); 
	code.ipdir=NORTH;
	break;
      case SOUTH: 
	if(RLEN==0) goto error;
	if(RET(1)==code.invert) code.ipdir=EAST;
	else if(RET(1) == !code.invert) code.ipdir=WEST;
	else goto error;
	RLEN--;
	break;
      case NORTH: 
	if(RLEN==0) goto error;
	if(RET(1)==0) RET(1)=1;
	else if(RET(1)==1) RET(1)=0;
	else goto error;
	code.ipdir ^= 1;
	code.invert ^= 1;
	break;
      }
      break;
    case '\'':
    case '`':
      if(DLEN==0) goto error;
      if((c=='\'') ^ code.invert) DATA(1)++;
      else DATA(1)--;
      break;
    case '+':
    case '-':
      if(DLEN<2) goto error;
      if((c=='+') ^ code.invert) DATA(2) += DATA(1);
      else DATA(2) -= DATA(1);
      break;
    case '%':
    case '*':
      if((c=='%') ^ code.invert){
	if(DLEN<2 || DATA(1)==0) goto error;
	DPUSH(DATA(1));
	DATA(2)=DATA(3)%DATA(1);
	DATA(3)=DATA(3)/DATA(1);
      }else{
	double prod;
	if(DLEN<3 || DATA(2)>=DATA(1) || DATA(2)<0 || DATA(1)==0) goto error;
	prod=(double)DATA(3)*DATA(1)+DATA(2);
	if(prod>0xffffffff) goto error;
	DATA(3)=prod;
	DATA(2)=DATA(1);
	DLEN--;
      }
      break;
    case '=':
      if(DLEN<2 || RLEN==0) goto error;
      RET(1) ^= DATA(2)==DATA(1);
      break;
    case 'g':
      if(DLEN<2 || RLEN==0) goto error;
      RET(1) ^= DATA(2)>DATA(1);
      break;
    case 'l':
      if(DLEN<2 || RLEN==0) goto error;
      RET(1) ^= DATA(2)<DATA(1);
      break;
    case '!':
      if(RLEN==0) goto error;
      RET(1) ^= 1;
      break;
    case '~':
      if(DLEN<1) goto error;
      DATA(1) = ~DATA(1);
      break;
    case '&':
      if(DLEN<3) goto error;
      DATA(1) ^= DATA(2)&DATA(3);
      break;
    case '|':
      if(DLEN<3) goto error;
      DATA(1) ^= DATA(2)|DATA(3);
      break;
    case '#':
      if(DLEN<2) goto error;
      DATA(2) ^= DATA(1);
      break;
    case '{':
    case '}':
      if((c=='{') ^ code.invert){
	if(DLEN<2) goto error;
	x=DATA(1)&(sizeof(int)*8-1);
	DATA(2) = (DATA(2)<<x) ^ (DATA(2)>>(sizeof(int)*8-x));
      }else{
	if(DLEN<2) goto error;
	x=DATA(1)&(sizeof(int)*8-1);
	DATA(2) = (DATA(2)>>x) ^ (DATA(2)<<(sizeof(int)*8-x));
      }
      break;
    case '(':
    case ')':
      if((c=='(') ^ code.invert) DPUSH(0)
      else{
        if(DLEN==0 || DATA(1)) goto error;
        DLEN--;
      }
      break;
    case 's':
      if(DLEN<2) goto error;
      x=DATA(1);
      DATA(1)=DATA(2);
      DATA(2)=x;
      break;
    case 'c':
      if(DLEN<3) goto error;
      x=DATA(2);
      DATA(2)=DATA(3);
      DATA(3)=x;
      break;
    case 'f':
      if(DLEN<3) goto error;
      x=DATA(1);
      DATA(1)=DATA(3);
      DATA(3)=x;
      break;
    case 'd':
    case 'b':
      if(DLEN<3) goto error;
      if((c=='d') ^ code.invert){
	x=DATA(3);
	DATA(3)=DATA(2);
	DATA(2)=DATA(1);
	DATA(1)=x;
      }else{
	x=DATA(1);
	DATA(1)=DATA(2);
	DATA(2)=DATA(3);
	DATA(3)=x;
      }
      break;
    case ':':
    case ';':
      if((c==':') ^ code.invert){
	if(DLEN==0) goto error;
	DPUSH(DATA(1));
      }else{
	if(DLEN<2 || DATA(1)!=DATA(2)) goto error;
	DLEN--;
      }
      break;
    case 'o':
    case 'u':
      if((c=='o') ^ code.invert){
	if(DLEN<2) goto error;
	DPUSH(DATA(2));
      }else{
	if(DLEN<3 || DATA(1)!=DATA(3)) goto error;
	DLEN--;
      }
      break;
    case '[':
    case ']':
      if((c=='[') ^ code.invert){
	if(DLEN==0) goto error;
	RPUSH(DATA(1));
	DLEN--;
      }else{
	if(RLEN==0) goto error;
	DPUSH(RET(1));
	RLEN--;
      }
      break;
    case '$':
      if(DLEN==0 || RLEN==0) goto error;
      x=DATA(1);
      DATA(1)=RET(1);
      RET(1)=x;
      break;
    case 'w':
      if(code.invert){
	if(OLEN<1) goto error;
	DPUSH(output.text[--OLEN]);
      }else{
	if(DLEN==0 || DATA(1)>255) goto error;
	if(!vismode){
	  putchar(DATA(1));
	  fflush(stdout);
	}
	BEXPAND(output,OLEN+1);
	output.text[OLEN++]=DATA(1);
	DLEN--;
      }
      break;
    case 'r':
      if(code.invert){
	if(DLEN==0) goto error;
	BEXPAND(input,ILEN+1);
	input.text[ILEN++]=DATA(1);
	DLEN--;
      }else{
	if(ILEN<1){
	  if(vismode){
	    drawall();
	  }
	  x=getkey();
	  if(x>127){
	    paused=1;
	    goto error;
	  }
	  DPUSH(x);
	}else{
	  DPUSH(input.text[--ILEN]);
	}
      }
      break;
    case '@':
      if(!vismode) exit(0);
      else goto error;
      break;
    case '?': code.invert ^= 1; break;
    case '\\': code.ipdir ^= 2; break;
    case '/': code.ipdir ^= 3; break;
    case ' ': break;
    default: goto error;
    }
    MOVE(code,ip);
  }while(--i);

error:
  if(stepback) timestamp-=n-i;
  else timestamp+=n-i;
}

