#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "bfi.h"

int load(window *w,char *filename){
  int fd;
  int len;
  int i,x,y;
  char *buf;
  int siz=0;

  /* Load the file into 1-dimensional array "buf" */
#ifdef USEDOS
  fd=open(filename,O_RDONLY|O_BINARY);
#else
  fd=open(filename,O_RDONLY);
#endif
  if(fd==-1) return -1;
  len=lseek(fd,0,SEEK_END);
  lseek(fd,0,SEEK_SET);
  buf=malloc(len);
  if(read(fd,buf,len)!=len){
    perror("Read failed: ");
    exit(1);
  }
  close(fd);

  /* Find its width & height */
  w->lenx=1;
  w->leny=0;
  for(i=0;i<len;i++){
    if(buf[i]==10){
      if(siz>w->lenx) w->lenx=siz;
      siz=0; w->leny++;
    }else if(buf[i]!=13) siz++;
  }

  /* Initialize window buffer */
  w->type=CODE;
  w->text=malloc(w->lenx*w->leny);
  memset(w->text,' ',w->lenx*w->leny);
  w->curdir=EAST;
  w->ipx=0;
  w->ipy=0;
  w->ipdir=EAST;
  w->invert=0;
  w->title=filename;
  data.leny=0;
  ret.leny=0;
  output.lenx=0;
  input.lenx=0;
  timestamp=0;
  stepback=0;

  /* Copy from the 1-dimensional "buf" to the 2-dimensional window data */
  for(x=0,y=0,i=0;i<len;i++){
    if(buf[i]=='@'){ w->ipx=MOD(x+1,w->lenx); w->ipy=y; }
    if(buf[i]==10){ x=0; y++; }
    else if(buf[i]!=13) w->text[y*w->lenx + x++]=buf[i];
  }
  free(buf);
  return 0;
}

int save(window *w){
  int fd=open(w->title,O_WRONLY|O_CREAT|O_TRUNC,S_IWUSR|S_IRUSR);
  int y;
  char nl='\n';

  if(fd==-1) return -1;
  for(y=0;y<w->leny;y++){
    if(write(fd,w->text+y*w->lenx,w->lenx)!=w->lenx) return -1;
    if(write(fd,&nl,1)!=1) return -1;
  }
  close(fd);
  return 0;
}

