#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <curses.h>
#include <time.h>
#include <signal.h>
#include "bfi.h"

char vismode;  /* 0=console mode, 1=visual mode */
char paused=1; /* 0=running, 1=paused */
char stepback; /* 0=stepping forwards, 1=stepping backwards */
char speed;    /* execution speed: 0=slowest, 15=fastest) */
int timestamp; 
int exitconfirm=0;
window code,data,ret,info,output,input;
window *sel=&code;  /* Selected window */
window *topsel=&data;

void drawinfo(){
  memset(info.text,' ',info.lenx*info.leny);
  sprintf(info.text,"time: %08x",timestamp);
  sprintf(info.text+info.lenx,"speed: %x      ",speed);
  if(paused) memcpy(info.text+2*info.lenx,"paused",6);
  else info.text[2*info.lenx]=' ';
}

void drawall(){
  drawbeg();
  drawwin(&code);
  drawwin(&data);
  drawwin(&ret);
  drawinfo();
  drawwin(&info);
  drawwin(&output);
  drawwin(&input);
  drawend(sel);
}

void ctrlc(){
  if(vismode){
    if(exitconfirm){
      message("");
      drawall();
      drawoff();
      exit(0);
    }else{
      message("Exit befreak?");
      exitconfirm=1;
    }
  }else{
    /*    vismode=1;
          drawon();
    */
    exit(0);
  }
}

void findhome(){
  int x,y;
  code.ipx=0;
  code.ipy=0;
  for(y=0;y<code.leny;y++){
    for(x=0;x<code.lenx;x++){
      if(code.text[y*code.lenx+x]=='@'){
	code.ipx=MOD(x+1,code.lenx);
	code.ipy=y;
	code.ipdir=0;
	code.invert=0;
	stepback=0;
	timestamp=0;
	return;
      }
    }
  }
}

void handlekey(int c){
  switch(c){
  case KEY_RIGHT:  
    sel->curdir=0; 
    MOVE(*sel,cur); 
    if(sel->curx==sel->markx) sel->markdx=1;
    if(sel->clip){
      sel->markx=MOD(sel->markx+1,sel->lenx);
    }
    break;
  case KEY_LEFT: 
    if(sel->curx==sel->markx) sel->markdx=0;
    sel->curdir=1; 
    MOVE(*sel,cur);
    if(sel->clip){
      sel->markx=MOD(sel->markx-1,sel->lenx);
    }
    break;
  case KEY_DOWN:  /* warning: real big mess follows */
  case KEY_UP:
    if(c==KEY_DOWN){
      sel->curdir=2;
    }else{
      sel->curdir=3;
      if(sel->cury==sel->marky) sel->markdy=0;
    }

    if(sel->type==BUFFER){
      int i;
      sel->curdir&=1;
      for(i=sel->scrx-1;i;i--){
	if(sel->text[sel->curx]=='\n') break;
	MOVE(*sel,cur);
      }
    }
    MOVE(*sel,cur); 
    if(c==KEY_DOWN && sel->cury==sel->marky) sel->markdy=1;
    if(c==KEY_DOWN){
      if(sel->clip){
	sel->marky=MOD(sel->marky+1,sel->leny);
      }   
    }else{
      if(sel->clip){
	sel->marky=MOD(sel->marky-1,sel->leny);
      }   
    }
    break;
  case 3:   /* CTRL-C */
    ctrlc();
    return;
  case 4:   /* CTRL-D */
    if(sel->clip) fliph(sel);
    break;
  case 1:   /* CTRL-A */
    if(sel->clip) flipv(sel);
    break;
  case 5:   /* CTRL-E */
    if(sel->clip) rotater(sel);
    break;
  case 17:  /* CTRL-Q */
    if(sel->clip) rotatel(sel);
    break;
  case 15:   /* CTRL-O */
    if(sel->clip) invert(sel);
    break;
#ifdef ALT_RIGHT
  case ALT_RIGHT:
#endif
#ifdef A_RIGHT
  case A_RIGHT:
#endif
  case 6:   /* CTRL-F */
    if(stepback){ 
      code.invert^=1;
      code.ipdir^=1;
      MOVE(code,ip);
      stepback=0;
    }else step(1);
    break;
#ifdef ALT_LEFT
  case ALT_LEFT:
#endif
#ifdef A_LEFT
  case A_LEFT:
#endif
  case 2:   /* CTRL-B */
    if(!stepback){
      code.invert^=1;
      code.ipdir^=1;
      MOVE(code,ip);
      stepback=1;
    }else step(1);
    break;
#ifdef ALT_DOWN
  case ALT_DOWN:
#endif
#ifdef A_DOWN
  case A_DOWN:
#endif
  case 16:   /* CTRL-P */
    if(speed>0) speed--;
    break;
#ifdef ALT_UP
  case ALT_UP:
#endif
#ifdef A_UP
  case A_UP:
#endif
  case 14:  /* CTRL-N */
    if(speed<15) speed++;
    break;
  case 18:  /* CTRL-R */
    prompt("rename: ");
    if(strlen(pmt)){
      code.title=malloc(strlen(pmt)+1);
      strcpy(code.title,pmt);
    } 
    break;
  case 23:  /* CTRL-W */
    if(save(&code)){
      char s[200]="cannot open: ";
      strcat(s,pmt);
      message(s);
    }else message("file saved");
    return;
  case 12:  /* CTRL-L */
    prompt("load file: ");
    if(strlen(pmt) && load(&code,pmt)){
      char s[200]="cannot open: ";
      strcat(s,pmt);
      message(s);
      return;
    }
    break;
  case 11:   /* CTRL-K */
    vismode=0;
    drawoff();
    break;
  case 24:  /* CTRL-X */
    if(sel->markx==-1){
      sel->markx=sel->curx;
      sel->marky=sel->cury;
      sel->markdx=1;
      sel->markdy=1;
    }else if(sel->clip){
      paste(sel);
      free(sel->clip);
      sel->clip=NULL;
      sel->markx=-1;
    }else{
      cut(sel);
    }
    break;
  case 27:  /* ESC */
    if(sel->clip){
      free(sel->clip);
      sel->clip=NULL;
      sel->markx=-1;
    }
    break;
  case 22:  /* CTRL-V */
    paste(sel);
    break;
  case '\t':
    if(sel==&code) sel=topsel;
    else{
      topsel=sel;
      sel=&code;
    }
    break;
  case KEY_F(1): 
    sel=&data;
    data.cury=DLEN;
    break;
  case KEY_F(2):
    sel=&ret;
    ret.cury=RLEN;
    break;
  case KEY_F(3):
    sel=&input;
    break;
  case KEY_F(4):
    sel=&output;
    output.curx=output.lenx;
    break;
  case KEY_F(5):
    input.lenx=0;
    output.lenx=0;
    data.leny=0;
    ret.leny=0;
    findhome();
    break;
#ifdef CTL_LEFT
  case CTL_LEFT:
#endif
#ifdef C_LEFT
  case C_LEFT:
#endif
  case KEY_F(7):
    if(code.lenx>1) resize(&code,code.lenx-1,code.leny);
    break;
#ifdef CTL_RIGHT
  case CTL_RIGHT:
#endif
#ifdef C_RIGHT
  case C_RIGHT:
#endif
  case KEY_F(8):
    resize(&code,code.lenx+1,code.leny);
    break;
#ifdef CTL_UP
  case CTL_UP:
#endif
#ifdef C_UP
  case C_UP:
#endif
  case KEY_F(9):
    if(code.leny>1) resize(&code,code.lenx,code.leny-1);
    break;
#ifdef CTL_DOWN
  case CTL_DOWN:
#endif
#ifdef C_DOWN
  case C_DOWN:
#endif
  case KEY_F(10):
    resize(&code,code.lenx,code.leny+1);
    break;
  case '\n':
    paused ^= 1;
    break;
  case '\b':
  case KEY_BACKSPACE:
      if(sel->type==STACK){
        if(sel->lenx>0){
          sel->curx=MOD(sel->curx-1,8);
          sel->data[sel->cury] &= ~((unsigned)0xf0000000 >> (sel->curx<<2));
        }
      }else{
	sel->curdir^=1;
	MOVE(*sel,cur);
	sel->curdir^=1;
        sel->text[sel->cury*sel->lenx+sel->curx]=' ';
      }
      break;
    
  case KEY_IC:
    if(sel->type==STACK){
      EXPAND(*sel,sel->leny+1);
      memmove(sel->data+sel->cury+1,sel->data+sel->cury,(sel->leny-sel->cury)*sizeof(unsigned));
      sel->leny++;
      sel->data[sel->cury]=0;
    }else if(sel->type==CODE){
      if(sel->ipx==sel->curx && sel->ipy==sel->cury) sel->invert ^= 1;
      else sel->invert=0;
      sel->ipx=sel->curx;
      sel->ipy=sel->cury;
      sel->ipdir=sel->curdir;
      timestamp=0;
      stepback=0;
    }
    break;
  case KEY_DC:
    if(sel->type==STACK){
      if(sel->cury<sel->leny){
	sel->leny--;
	memmove(sel->data+sel->cury,sel->data+sel->cury+1,(sel->leny-sel->cury)*sizeof(unsigned));
      }
    }else{
      sel->text[sel->cury*sel->lenx+sel->curx]=' ';
    }
    break;
  default:
    if(sel->type==STACK){
      if(sel->cury<sel->leny){
	int v;
	if(c>='0' && c<='9') v=c-'0';
	else if(c>='a' && c<='f') v=c-'a'+10;
	else if(c>='A' && c<='F') v=c-'A'+10;
	else break;
	sel->data[sel->cury] &= ~((unsigned)0xf0000000 >> (sel->curx<<2));
	sel->data[sel->cury] |= (unsigned)v << ((7-sel->curx)<<2);
	sel->curx++;
	sel->curx=MOD(sel->curx,8);
      }
    }else{
      if(sel->clip) break;
      if(c<32 || c>127) break;
      if(sel->cury<sel->leny && sel->curx<sel->lenx)
	sel->text[sel->cury*sel->lenx+sel->curx]=c;
      if(c=='\\') sel->curdir ^= 2;
      else if(c=='/') sel->curdir ^= 3;
      MOVE(*sel,cur);
    }
  }
  exitconfirm=0;
  message("");
}

void smallkey(int c){
  if(c==11){
    vismode=1;
    drawon();
  }else{
    BEXPAND(input,ILEN+1);
    memmove(input.text+1,input.text,ILEN);
    input.text[0]=c;
    ILEN++;
  }
}

void positionwins(){  /* Move windows to their default locations/size */
  int y;

  y=termy/5;
  if(y<5) y=5;
  code.posx=0;
  code.posy=y;
  code.scrx=termx;
  code.scry=termy-y;
  data.posx=0;
  data.posy=0;
  data.scrx=8;
  data.scry=y;
  ret.posx=9;
  ret.posy=0;
  ret.scrx=8;
  ret.scry=y;
  ret.leny=RLEN;
  info.posx=18;
  info.posy=0;
  info.scrx=15;
  info.scry=y-2;
  output.posx=34;
  output.posy=0;
  output.scrx=termx-34;
  output.scry=y;
  input.posx=18;
  input.posy=y-2;
  input.scrx=15;
  input.scry=2;
  center(&code,code.curx,code.cury,0);
  if(sel==&data) center(&data,data.curx,data.cury,1);
  else center(&data,data.curx,data.leny,1);
  if(sel==&ret) center(&ret,ret.curx,ret.cury,1);
  else center(&ret,ret.curx,ret.leny,1);
  if(sel==&output) center(&output,output.curx,0,0);
  else center(&output,output.lenx,0,1);
}


int power(int b,int n){
  int x;
  for(x=1;n;n--) x*=b;
  return x;
}

void idle(){
  usleep(20000);
}

int main(int argc,char **argv){
  int c,del=1;

  if(argc>2){
    fprintf(stderr,"usage: bfi [file]\n");
    exit(1);
  }
  if(argc==2){
    load(&code,argv[1]);
    paused=0;
    speed=15;
  }else{
    code.title="unnamed";
    code.type=CODE;
    code.lenx=21;
    code.leny=21;
    code.text=malloc(code.lenx*code.leny);
    clearwin(&code);
    vismode=1;
    drawon();
  }

#ifndef USEDOS
  signal(SIGINT,ctrlc);
#endif

  data.type=STACK;
  data.title="data";
  data.lenx=8;
  ret.type=STACK;
  ret.title="return";
  ret.lenx=8;
  info.type=TEXT;
  info.title="info";
  info.lenx=14;
  info.leny=3;
  info.text=malloc(info.lenx*info.leny);
  info.markx=-1;
  output.type=BUFFER;
  output.title="output";
  input.type=BUFFER;
  input.title="input";
  for(;;){
    if(vismode){
      positionwins();
      do{
        drawall();
        c=checkkey();
        if(c>0) handlekey(c);
      }while(c>0);
    }
    if(!paused){
      if(speed<=2){
        if(--del==0){
          step(1);
          del=power(2,2-speed);
        }
      }else if(speed<10){
        step(power(3,speed-2));
      }else{
        step(power(3,8));
        if(--del==0){
          del=power(2,speed-10);
          if(speed!=15) idle();
        }
      }
    }
    if(paused || speed<10){
     idle();
    }
  }
  return 0;
}
