/* #define USEDOS */

typedef struct{
  int type;        /* See window types below */
  int posx,posy;   /* The top-left location of the window on the screen */
  int scrx,scry;   /* The dimensions of the window on the screen */
  int viewx,viewy; /* The top-left location that we're looking at */
  int lenx,leny;   /* The dimensions of the window buffer */
  char *title;     /* Title written above the window when drawn */
             
  char *text;      /* The window data (used for CODE/TEXT windows) */
  char *clip;      /* Clipboard data */
  unsigned *data;  /* The window data (used for DATA windows) */
  int cap;         /* Capacity of text/data (used for STACK&BUFFER) */
  int curx,cury;   /* The location of the cursor in the window buffer */
  int curdir;      /* Direction the cursor is facing */
  int markx,marky; /* Location of the bookmark, used for cut&paste */
  int markdx,markdy;/* Direction of the selection from the mark */
  int ipx,ipy;     /* Location of the IP (ipx=-1 if this window has none) */
  int ipdir;       /* Location the IP is facing */
  char invert;     /* 0=running normal, 1=running inverted */
}window;

/* -------- main.c ------------ */
extern window code;   /* The main window */
extern window data;   /* The data stack/window */
extern window ret;    /* The return stack/window */
extern window output; /* The output window */
extern window input;  /* The input window */
extern char stepback,paused,vismode;
extern int timestamp;
void drawall();

/* -------- curses.c ---------- */
extern char pmt[200];
extern int termx,termy;
void drawon();           /* Initialize Curses (used in visual mode) */
void drawoff();          /* Shut down Curses (used in console mode) */
void drawbeg();          /* Begin drawing the frame (clear backbuffer) */
void drawwin(window *w); /* Draw a window to the screen */
void drawend(window *w); /* Finish drawing the frame (show backbuffer) */
char *prompt(char *s);   /* Prompt for a string (used for load/save file) */
void message(char *s);   /* Print a message (used for error messages) */
int  checkkey();         /* Non-blocking getch */
int  getkey();           /* Blocking getch */

/* -------- window.c ------------- */
void clearwin(window *w);   /* Clear the window's state, fill with spaces */
void resize(window *w,int x,int y);   /* Resize the window data */
void cut(window *w);
void paste(window *w);
void fliph(window *w);      /* Horizontal flip of window clip */
void flipv(window *w);      /* Vertical flip of window clip */
void rotater(window *w);    /* Clockwise rotation of window clip */
void rotatel(window *w);    /* Counter-clockwise rotation of window clip */   
void invert(window *w);     /* Invert all instructions in window clip */
void center(window *w,int x,int y,char bound); /* Center window view */

/* -------- step.c ------------ */
void step(int n); /* Takes n steps forwards */

/* -------- file.c ------------ */
int save(window *);
int load(window *,char *filename);

/* Window types */
#define CODE   0
#define STACK  1
#define TEXT   2
#define BUFFER 3

/* Directions */
#define EAST 0
#define WEST 1
#define SOUTH 2
#define NORTH 3

#define SWAP(x,y) {tmp=(x); (x)=(y); (y)=tmp;}
#define MOD(x,n) ((x)>=(n)?(x)-(n):(x)<0?(x)+(n):(x))
#define SAT(x,n) ((x)>=(n)?n:(x)<0?0:(x))
#define MOVE(w,a) { \
  if((w).a##dir==EAST) (w).a##x++; \
  else if((w).a##dir==WEST) (w).a##x--; \
  else if((w).a##dir==SOUTH) (w).a##y++; \
  else if((w).a##dir==NORTH) (w).a##y--; \
  if((w).type==CODE){ \
    (w).a##x = MOD((w).a##x, (w).lenx); \
    (w).a##y = MOD((w).a##y, (w).leny); \
  }else{          \
    (w).a##x = MOD((w).a##x, (w).lenx); \
    (w).a##y = SAT((w).a##y, (w).leny); \
  } } 
#define EXPAND(s,n) if((s).cap<(n)){ \
  (s).cap=(n)<<1; \
  (s).data=realloc((s).data,(s).cap*sizeof(unsigned)); \
  }
#define BEXPAND(s,n) if((s).cap<(n)){ \
  (s).cap=(n)<<1; \
  (s).text=realloc((s).text,(s).cap); \
  }
#define PUSH(s,x){ EXPAND(s,(s).leny+1); (s).data[(s).leny]=(x); (s).leny++; }
#define DATA(i) (data.data[data.leny-(i)])
#define DPUSH(x) PUSH(data,x)
#define DLEN data.leny
#define RET(i) (ret.data[ret.leny-(i)])
#define RPUSH(x) PUSH(ret,x)
#define RLEN ret.leny
#define OLEN output.lenx
#define ILEN input.lenx
