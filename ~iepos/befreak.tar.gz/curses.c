#include <string.h>
#include <curses.h>
#include "bfi.h"

int termx,termy;
char pmt[200];
char msg[200];

void drawon(){
  initscr();
  start_color();
  cbreak();
  keypad(stdscr,1);
  nodelay(stdscr,1);
  noecho();
  meta(stdscr,FALSE);
#ifdef USEDOS
  _setcursortype(1);  /* Solid-block cursor */
#else
  curs_set(2);
#endif
  init_pair(1,COLOR_WHITE,COLOR_BLUE);
  init_pair(2,COLOR_WHITE,COLOR_WHITE);
  init_pair(3,COLOR_WHITE,COLOR_CYAN);
  init_pair(4,COLOR_WHITE,COLOR_MAGENTA);
  init_pair(5,COLOR_GREEN,COLOR_BLUE);
}

void drawoff(){
  endwin();
#ifdef USEDOS
  _setcursortype(2);
#endif
}

void drawwin(window *w){
  int i,x,y,minx,miny,maxx,maxy,cx,cy,cmaxx,cmaxy,c;

  /* How far can we draw without running out of window data? */
  if(w->viewy<0) miny=-w->viewy;
  else miny=0;
  if(w->leny - w->viewy < w->scry-1) maxy=w->leny - w->viewy;
  else maxy=w->scry-1;
  if(w->viewx<0) minx=-w->viewx;
  else minx=0;
  if(w->lenx - w->viewx < w->scrx) maxx=w->lenx - w->viewx;
  else maxx=w->scrx;

  attrset(0);
  if(w->type==STACK){
    for(y=miny;y<maxy;y++){
      mvprintw(y+w->posy+1,w->posx,"%08x",w->data[y+w->viewy]);
    }
  }else{
    if(w->type==BUFFER){
      x=0;
      y=1;
      move(y+w->posy,x+w->posx);
      for(i=w->viewx;i<w->lenx;i++){
	if(x==w->scrx || w->text[i]=='\n'){
	  x=0;
	  y++;
	  if(y==w->scry) break;
	  move(y+w->posy,x+w->posx);
	}
	if(w->text[i]!='\n'){
	  addch(w->text[i]);
	  x++;
	}
      }
    }else{
      /* Draw the body of the window */
      for(y=miny;y<maxy;y++){
	move(y+w->posy+1,w->posx+minx);
	for(x=minx;x<maxx;x++){
	  c=w->text[(y+w->viewy)*w->lenx+w->viewx+x];
	  if(w->type==CODE)
	    attrset(COLOR_PAIR(1));
	  else
	    attrset(COLOR_PAIR(0));
	  if(c=='/' || c=='\\' || c=='^' || c=='>' || c=='<' || c=='v')
	    attrset(COLOR_PAIR(1)|A_BOLD);

	  if(w->markx>=0){
	    cx=w->markdx
	      ?MOD(x+w->viewx-w->markx,w->lenx)
	      :MOD(x+w->viewx-w->curx,w->lenx);
	    cy=w->markdy
	      ?MOD(y+w->viewy-w->marky,w->leny)
	      :MOD(y+w->viewy-w->cury,w->leny);
	    cmaxx=w->markdx
	      ?MOD(w->curx-w->markx,w->lenx)
	      :MOD(w->markx-w->curx,w->lenx);
	    cmaxy=w->markdy
	      ?MOD(w->cury-w->marky,w->leny)
	      :MOD(w->marky-w->cury,w->leny);
	    if(cx<=cmaxx && cy<=cmaxy){
	      attrset(COLOR_PAIR(1)|A_REVERSE);
	      if(w->clip && w->clip[cy*(cmaxx+1)+cx]!=' '){
	        addch(w->clip[cy*(cmaxx+1)+cx]);
	      }else{
		addch(c);
	      }
	    }else{
	      addch(c);
	    }
	  }else addch(c);
	}
      }
      
      /* Draw the IP */
      if(w->type==CODE && w->ipx>=w->viewx && w->ipx<w->viewx+w->scrx &&
	 w->ipy>=w->viewy && w->ipy<w->viewy+w->scry-1){
	if(w->invert) attrset(A_BOLD|COLOR_PAIR(4));
	else attrset(A_BOLD|COLOR_PAIR(3));
	mvaddch(w->posy+1+w->ipy-w->viewy,
		w->posx+w->ipx-w->viewx,
		w->text[w->ipy*w->lenx+w->ipx]);
	
	/* ... and its tail */
	x = w->ipx;
	y = w->ipy;
	if(w->ipdir==EAST) x=MOD(x-1,w->lenx);
	if(w->ipdir==WEST) x=MOD(x+1,w->lenx);
	if(w->ipdir==SOUTH) y=MOD(y-1,w->leny);
	if(w->ipdir==NORTH) y=MOD(y+1,w->leny);
	if(x>=w->viewx && x<w->viewx+w->scrx &&
	   y>=w->viewy && y<w->viewy+w->scry-1){
	  attrset(A_BOLD | COLOR_PAIR(0));
	  mvaddch(w->posy+1+y-w->viewy,
		  w->posx+x-w->viewx,
		  w->text[y*w->lenx+x]);
	}
      }
    }
  }

  /* Draw the title */
  attrset(COLOR_PAIR(2)|A_BOLD);
  maxx=strlen(w->title);
  mvaddnstr(w->posy,w->posx,w->title,maxx);
  for(i=maxx;i<w->scrx;i++) addch(' ');
}

void drawbeg(){
  erase();   /* Clear the back buffer */
  getmaxyx(stdscr,termy,termx);
}

void drawend(window *w){
  int x,y,i;

  /* Draw the "message" */
  attrset(COLOR_PAIR(0));
  mvprintw(termy-1,0,"%s",msg);

  if(w->type==BUFFER){
    x=0;
    y=0;
    for(i=w->viewx;i<w->curx&&y<w->scry;i++){
      if(x==w->scrx-1 || w->text[i]=='\n'){
	x=0;
	y++;
      }else x++;
    }
    if(i!=w->curx) x=-1;
  }else{
    x=w->curx-w->viewx;
    y=w->cury-w->viewy;
  }
  if(x>=0 && x<w->scrx && y>=0 && y<w->scry)
    move(y+w->posy+1,x+w->posx);
  refresh(); /* Reveal the back buffer */
}

void drawscrxy(int *x,int *y){
}

char *prompt(char *s){
  int x,y;
  getmaxyx(stdscr,y,x);
  echo();
  nodelay(stdscr,0);
  attrset(0);
  mvprintw(y-1,0,s);
  wgetstr(stdscr,pmt);
  nodelay(stdscr,1);
  noecho();
  return pmt;
}

void message(char *s){
  strcpy(msg,s);
}

int checkkey(){
  return getch();
}

int getkey(){
  int c;
  if(vismode){
    move(termy-1,0);
    nodelay(stdscr,0);
    c=getch();
    nodelay(stdscr,1);
  }else{
    c=getchar();
    if(c==''){
      vismode=1;
      drawon();
    }
  }
  return c;
}
