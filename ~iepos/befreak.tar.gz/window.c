#include <stdlib.h>
#include <string.h>
#include "bfi.h"

void clearwin(window *w){
  if(w->type==CODE || w->type==TEXT){
    memset(w->text,' ',w->lenx*w->leny);
    w->markx=-1;
    w->ipx=0;
    w->ipy=0;
    w->ipdir=EAST;
    w->invert=0;
  }else{
    w->lenx=0;
  }
}

void resize(window *w,int newx,int newy){
  int y;
  char *newbuf=malloc(newx*newy);
  int smallx=newx<w->lenx?newx:w->lenx;
  int smally=newy<w->leny?newy:w->leny;
  int cmaxx,cmaxy;

  cmaxx=w->markdx
    ?MOD(w->curx-w->markx,w->lenx)
    :MOD(w->markx-w->curx,w->lenx);
  cmaxy=w->markdy
    ?MOD(w->cury-w->marky,w->leny)
    :MOD(w->marky-w->cury,w->leny);
  if(newx<cmaxx || newy<cmaxy) return;

  for(y=0;y<smally;y++){
    memcpy(newbuf+y*newx,w->text+y*w->lenx,smallx);
    memset(newbuf+y*newx+smallx,' ',newx-smallx);
  }
  memset(newbuf+smally*newx,' ',newx*(newy-smally));
  free(w->text);
  w->text=newbuf;
  w->lenx=newx;
  w->leny=newy;

  if(w->ipx>=newx) w->ipx=newx-1;
  if(w->ipy>=newy) w->ipy=newy-1;
  if(w->curx>=newx) w->curx=newx-1;
  if(w->cury>=newy) w->cury=newy-1;
}

void cut(window *sel){
  int cmaxx,cmaxy;
  int i,j,x,y;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);
  sel->clip=malloc((cmaxx+1)*(cmaxy+1));
  if(sel->markdy) y=sel->marky;
  else y=sel->cury;
  for(i=0;i<=cmaxy;i++){
    if(sel->markdx) x=sel->markx;
    else x=sel->curx;
    for(j=0;j<=cmaxx;j++){
      sel->clip[i*(cmaxx+1)+j]=sel->text[y*sel->lenx+x];
      sel->text[y*sel->lenx+x]=' ';
      x=MOD(x+1,sel->lenx);
    }
    y=MOD(y+1,sel->leny);
  }
}

void paste(window *sel){
  int cmaxx,cmaxy;
  int i,j,x,y,c;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);
  if(sel->markdy) y=sel->marky;
  else y=sel->cury;
  for(i=0;i<=cmaxy;i++){
    if(sel->markdx) x=sel->markx;
    else x=sel->curx;
    for(j=0;j<=cmaxx;j++){
      c=sel->clip[i*(cmaxx+1)+j];
      if(c!=' ') sel->text[y*sel->lenx+x]=c;
      x=MOD(x+1,sel->lenx);
    }
    y=MOD(y+1,sel->leny);
  }
}

int flipch(char c){
  switch(c){
  case '<': return '>';
  case '>': return '<';
  case '/': return '\\';
  case '\\': return '/';
  }
  return c;
}

int flipcv(char c){
  switch(c){
  case '^': return 'v';
  case 'v': return '^';
  case '/': return '\\';
  case '\\': return '/';
  }
  return c;
}

int rotcr(char c){
  switch (c){
  case '^': return '>';
  case '>': return 'v';
  case 'v': return '<';
  case '<': return '^';
  case '/': return '\\';
  case '\\': return '/';
  }
  return c;
}

int rotcl(char c){
  switch (c){
  case '^': return '<';
  case '<': return 'v';
  case 'v': return '>';
  case '>': return '^';
  case '/': return '\\';
  case '\\': return '/';
  }
  return c;
}

int invertc(char c){
  switch (c){
  case '(': return ')';
  case ')': return '(';
  case '[': return ']';
  case ']': return '[';
  case '{': return '}';
  case '}': return '{';
  case 'd': return 'b';
  case 'b': return 'd';
  case '\'': return '`';
  case '`': return '\'';
  case '+': return '-';
  case '-': return '+';
  case '*': return '%';
  case '%': return '*';
  case ':': return ';';
  case ';': return ':';
  case 'o': return 'u';
  case 'u': return 'o';
  }
  return c;
}

void fliph(window *sel){
  int cmaxx,cmaxy;
  int i,j,tmp;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);
  for(i=0;i<=cmaxy;i++){
    for(j=0;j<=cmaxx>>1;j++){
      tmp=sel->clip[i*(cmaxx+1)+j];
      sel->clip[i*(cmaxx+1)+j]=flipch(sel->clip[i*(cmaxx+1)+cmaxx-j]);
      sel->clip[i*(cmaxx+1)+cmaxx-j]=flipch(tmp);
    }
  }
  sel->markdx ^= 1;
  if(sel->markdx) sel->markx=MOD(sel->curx-cmaxx,sel->lenx);
  else sel->markx=MOD(sel->curx+cmaxx,sel->lenx);
  
}

void flipv(window *sel){
  int cmaxx,cmaxy;
  int i,j,tmp;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);
  for(i=0;i<=cmaxy>>1;i++){
    for(j=0;j<=cmaxx;j++){
      tmp=sel->clip[i*(cmaxx+1)+j];
      sel->clip[i*(cmaxx+1)+j]=flipcv(sel->clip[(cmaxy-i)*(cmaxx+1)+j]);
      sel->clip[(cmaxy-i)*(cmaxx+1)+j]=flipcv(tmp);
    }
  }
  sel->markdy ^= 1;
  if(sel->markdy) sel->marky=MOD(sel->cury-cmaxy,sel->leny);
  else sel->marky=MOD(sel->cury+cmaxy,sel->leny);
}

void rotater(window *sel){
  char *newclip;
  int x,y,cmaxx,cmaxy,tmp;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);

  if(cmaxx>sel->leny || cmaxy>sel->lenx) return;
  newclip=malloc((cmaxx+1)*(cmaxy+1));
  for(y=0;y<=cmaxy;y++){
    for(x=0;x<=cmaxx;x++){
      newclip[x*(cmaxy+1)+cmaxy-y]=rotcr(sel->clip[y*(cmaxx+1)+x]);
    }
  }
  SWAP(sel->markdx,sel->markdy);
  SWAP(cmaxx,cmaxy);
  sel->markdx ^= 1;
  if(sel->markdx) sel->markx=MOD(sel->curx-cmaxx,sel->lenx);
  else sel->markx=MOD(sel->curx+cmaxx,sel->lenx);
  if(sel->markdy) sel->marky=MOD(sel->cury-cmaxy,sel->leny);
  else sel->marky=MOD(sel->cury+cmaxy,sel->leny);
  free(sel->clip);
  sel->clip=newclip;
}

void rotatel(window *sel){
  char *newclip;
  int x,y,cmaxx,cmaxy,tmp;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);

  if(cmaxx>sel->leny || cmaxy>sel->lenx) return;
  newclip=malloc((cmaxx+1)*(cmaxy+1));
  for(y=0;y<=cmaxy;y++){
    for(x=0;x<=cmaxx;x++){
      newclip[(cmaxx-x)*(cmaxy+1)+y]=rotcl(sel->clip[y*(cmaxx+1)+x]);
    }
  }
  SWAP(sel->markdx,sel->markdy);
  SWAP(cmaxx,cmaxy);
  sel->markdy ^= 1;
  if(sel->markdx) sel->markx=MOD(sel->curx-cmaxx,sel->lenx);
  else sel->markx=MOD(sel->curx+cmaxx,sel->lenx);
  if(sel->markdy) sel->marky=MOD(sel->cury-cmaxy,sel->leny);
  else sel->marky=MOD(sel->cury+cmaxy,sel->leny);
  free(sel->clip);
  sel->clip=newclip;
}

void invert(window *sel){
  int x,y,cmaxx,cmaxy;
  cmaxx=sel->markdx
    ?MOD(sel->curx-sel->markx,sel->lenx)
    :MOD(sel->markx-sel->curx,sel->lenx);
  cmaxy=sel->markdy
    ?MOD(sel->cury-sel->marky,sel->leny)
    :MOD(sel->marky-sel->cury,sel->leny);
  for(y=0;y<=cmaxy;y++){
    for(x=0;x<=cmaxx;x++){
      sel->clip[y*(cmaxx+1)+x]=invertc(sel->clip[y*(cmaxx+1)+x]);
    }
  }
}

void center(window *w,int x,int y,char bound){
  if(w->type==BUFFER){
    int i=x,j;
    int n;

    if(bound) n=w->scry-2;
    else n=(w->scry>>1)-1;
    for(;n&&i>0;i--){
      for(j=w->scrx;j&&i>0;j--,i--){
	if(w->text[i-1]=='\n') break;
      }
      n--;
    }
    if(i<0) i=0;
    w->viewx=i;
  }else{
    w->viewx=x-w->scrx/2;
    w->viewy=y-(w->scry-1)/2;
    if(bound){
      if(w->viewx+w->scrx > w->lenx) w->viewx = w->lenx-w->scrx;
      if(w->viewx<0) w->viewx=0;
      if(w->type==STACK){
	if(w->viewy+w->scry > w->leny+2) w->viewy = w->leny+2-w->scry;
      }else{
	if(w->viewy+w->scry > w->leny+1) w->viewy = w->leny+1-w->scry;
      }
      if(w->viewy<0) w->viewy=0;
    }
  }
}
